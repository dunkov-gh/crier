#!/bin/bash
#This is designed to prompt you for the system name you wish to visit
#This needs to be in the same directory as the location of the system and watch runners.
echo -n "system name: "
read -r name
wait
cp template_system $name
#wait
cp template_watch $name"_watch"
wait
sed -i 's/ABC-12/'$name'/g' $name
wait
sed -i 's/<SYSTEMNAME>/'$name'/g' $name"_watch"