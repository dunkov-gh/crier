This application is designed to execute OCR (Optical Character Recognition) on Screenshots for the Eve Echoes mobile game. Due to the nature of being a mobile game on various devices, with equally variable screen resolution(s), using the ee-town-crier application will require unique configuration based on the imeplementation method used.

There are two implementation methods for the ee-town-crier application:
1) Using an Android Emulator (Bluestacks 5 was used for development)
2) Using a mobile device (this requires an advanced setup configuration)

Below are the following Requirements for running the ee-town-crier application:
- An environment capable of running AWK, SED, Python modules (Linux with BASH or CygWin preferred)
- OCR Tesseract Open Source Tool
- Imagemagick (optinal for cropping if needed) Imagemagick
- AutoHotKey (for Emaulator implementations) (optional)

Basic Setup on Emulator
- BlueStacks
- Designated Folder for Emaulator Screenshots
-- Can be local folder or network, so long as this folder is accessible to the ee-town-crier application

Advanced setup on Android (to avoid running emulator on PC and only using mobile)
- MacroDroid, or automated screenshot capture app
- SSHelper, or other form of SSH Server app for Android
- Creation of ssh keys for passwordless login (pub and private)
- This method requires a precis MacroDroid to clean up images taken, or the device will fillup and cease operations

Linux Packages required:
apt install tesseract-ocr
apt install python
apt install python3
apt install python-pip
apt install python3-pip
apt-get install imagemagick

Tesseract languages required:
tesseract-ocr-chi_sim
tesseract-ocr-tra_sim
tesseract-ocr-rus
tesseract-ocr-jpn
tesseract-ocr-spa
tesseract-ocr-deu
tesseract-ocr-kor

Commands for Tesseract Language packs:
apt-get install tesseract-ocr-chi_sim tesseract-ocr-tra_sim tesseract-ocr-jpn tesseract-ocr-rus tesseract-ocr-spa tesseract-ocr-deu tesseract-ocr-kor

Ubuntu in Windows Commands for language packs (chinese name packs are slightly different):
apt-get install tesseract-ocr-chi-sim tesseract-ocr-chi-tra tesseract-ocr-jpn tesseract-ocr-rus tesseract-ocr-spa tesseract-ocr-deu tesseract-ocr-kor

Default install patch is preferred /opt/ee-town-crier, but update pathing as needed

====For installs using Ubuntu via Windows (10) Marketplace:=====
Perform steps listed here: https://www.lifewire.com/install-bash-on-windows-10-4101773
After that's done, do a quick "sudo su -"
Once as root, perform steps here: https://tesseract-ocr.github.io/tessdoc/Installation.html (be sure to put proper distro name.. had to update from "bionic" to "jammy"
Finally one last "apt update"

Ubuntu on Windows Folder location: (Folder name Ubuntu_**** will changed based on your install)
C:\Users\USERNAME\AppData\Local\Packages\CanonicalGroupLimited.Ubuntu_79rhkp1fndgsc\LocalState\rootfs

====USING THE APP REQUIRES AN EXACT SCREENSHOT====
The key element of OCR is capturing the overview. The overview should be set to only show hostiles.
The App needs to very carefully crop and screenshot the overview for the respective client. To do this, it is highly reccomended that you use an app capable of a precision screenshot of overview which OMITS Distance and Icon.
It is imperitive that the cropped-capture onlythe Pilots Name, and ShipType.
OBS version 28.x supports a plugin that allows for a Screenshot Filter. This, combined with a Crop/Pad filter, allows for precision screenshots of overviews, cutting down on processing time. Plugin URL: https://github.com/obsproject/obs-studio/releases/tag/28.1.2
To precisly Crop a video in OBS (using the Crop/Pad filter), reference the following: https://streamsentials.com/how-to-crop-in-obs/
If you are not using OBS 28.x or any other capture method, any method will work for tesseract to process the image, but the image needs to have all of the erroneous information excluded from the screenshot; This can be a very trial-and-error laden process to refine. There are lines in the script that calls for a precision crop to be performed, but be aware that while will add 1-3 seconds of additional processing to each screenshot.
For best results, crop the overview so that the only the pilot name and ship type are available. If the icon and distance are visibile, too much information will be collected and can deliver confusing results

====FOLDERS ARE REQUIRED FOR EACH CLIENT RUN====
Each folder requires a unique name, an Eve System name. This can be auto-parsed technically, but a static folder for the screenshots to be parsed/processed in is required at the screenshot destination. Inside that folder an additional one called "capture" is required. The folder struction will look like: \\INSTALLPATH\SYSTEMNAME\CAPTURE
This is required because the images have to be inverted before processed, as Tesseract works best on inverted images (and Eve is a dark game)

====MAKING SYSTEMS AND DAEMONS====
To creat both a system and watch daemon, run the 'template_make_system_make_watch' file. This will prompt you for a system that that you wish to visit, and also create the daemon for processing images from that system
To create a new system for the app, copy the "template_system" file into the name of the system you'd like.
e.g., "cp template_system F-1234"
To create a respective "lazy" Daemon, copy the template_watch" file into the name of the respective system recently made
e.g., "cp template_watch watch_F-1234"
Note that you will need to confirm/update the pathing in EACH respective file to ensure that the capture locations and daemon have the correct inputs

