#!/bin/bash
##################################
#    STOP - READ ALL COMMENTS    #
##################################
#
#
#Variables (Only SYSTEMNAME should require change, as each)
SYSTEMNAME="ABC-12"
INSTALLPATH="/opt/ocr"
IMAGEPATH="/$SYSTEMNAME/"
IMAGEPATH2="/$SYSTEMNAME/capture"
#
if ls -l $IMAGEPATH | grep -i png;
then
#
#Switch to directory and locally call all executables
cd $(dirname $0)
#--------------------------------------------------------
#Convert the snip from black background to a white one, which is better for OCR to run agains
convert $IMAGEPATH/*.png -channel RGB -negate $IMAGEPATH2/inverted.png
wait
#Remove original capture image, to ensure 2nd false read doens't occur
rm -f $IMAGEPATH/*.png
wait
#Optical Character Recognition (OCR), parses the junk and is primed for CURL 
output_system="ABC-123 gate" ### This is the static option, in case parsing is not desired
wait
echo "System capture completed"
output_overview=`tesseract $IMAGEPATH2/inverted.png stdout --psm 6 --dpi 400 -l eng+chi_sim+chi_tra+rus+jpn+spa+deu+kor | awk -F" " '{print $1,$2,$3,$4,$5}' | sed 's/^[ \t]*//' | sed 's/[ \t]*$//' |  sed 's/\]/\] /' |  tr -d '{}' | tr '|' ' ' | tr -d '1' | tr -d '=' | sed 'N;s/\n/ /' | sed 'N;s/\n/ /' | tr -d '\014' | sed 's/^/\\n/' | tr '\n' ' ' | sed 's/o.mn.7//' | tr -d '\^'`
wait
echo "Overview capture completed"
wait
echo "System and Overview Parse Check"
#Quick error checking for parsed name, before moving on to a 'filter' 
echo "SYS: $output_system"
echo "OVW: $output_overview"
#
#This grep looks for parenthesis, indicating ship type, with an "OR" to capture Corporation Tag by "["
grepOVW=`echo $output_overview | grep "(" | grep "\["`
echo "Grep overview: $grepOVW"
#
#Syntax Validation: This means that if the grepOVW is successful, the CURL can execute. If not, end script.
	if [[ $grepOVW != "" ]];
	then
#Paste a webhook
	curl \
	  -H "Content-Type: application/json" \
	  -d '{"username": "'"$SYSTEMNAME"'", "content": "'"$output_overview"'"}' \
	  "https://discord.com/api/webhooks/1234512345123451452/asdkljklsadjlkasjlkasjldkjasjdalskjldkasjkjdsa"
	wait
#--------------------------------------------------------
# This script is designed to clean up all artifacts in the capture directory
#
	echo "CURL sent"
	else
	echo "No matching syntax overview"
	fi
wait
rm -f $IMAGEPATH/*.png
wait
rm -f $IMAGEPATH2/*.png
echo "Cleanup Completed"
#end of IF worker
fi