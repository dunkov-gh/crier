#!/bin/bash
#This invokes a 2 second watch, constantly running the processing script, for each respective system made, and runs under its own PID
nohup watch /opt/<SYSTEMNAME> &> /dev/null &